// Подключение js-файлов с помощью rigger-а

// Modules
//= modules/no-link.js
//= modules/open-popup.js

